<?php

		
		$vkey = $_POST['vkey'];
		include '../../../admin/conection.php';
		$resultSet = $mysqli->query("Select verified, vkey FROM login WHERE verified = 0 AND vkey = '$vkey' LIMIT 1");
		
		if($resultSet->num_rows == 1){
			//validate the email
			$update = $mysqli->query("UPDATE login SET verified = 1 WHERE vkey = '$vkey' LIMIT 1");
			
			if ($update){
				echo 1;
				return;
			}
		}else{
			
			echo -1;
			return;
			
			
		}

?>
