<?php






$mysqli = new mysqli("localhost", "usuaruio1_admin", "AjaMW#c;zCi0", "usuario1_business_admin");

if(mysqli_connect_error()){

echo 'Conection Failed: ', mysqli_connect_error();
exit();

}

$mysqli2 = new mysqli("localhost", "remesafe_remesas", "q#FMxQgrVE;A", "remesafe_remesas");

if(mysqli_connect_error()){

    echo 'Conection Failed: ', mysqli_connect_error();
    exit();
    
    }


?>