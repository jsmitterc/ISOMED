<?php 


			include '../../php/conection.php';
			include '../../php/session.php';
		
				$user = $_SESSION['id'];
				$sql = "SELECT * FROM login WHERE id='$user'";
				$result = $mysqli->query($sql);
				$row = mysqli_fetch_assoc($result);
				$myclientid = $row['client'];
				$permission = $row['privileges'];
				$agent = $row['Client_id'];
				
				$currency = strtoupper(mysqli_real_escape_string($mysqli,$_POST['currency']));

		$sql = "SELECT SUM(balance) as b FROM rv_cuentas JOIN rv_banks ON rv_cuentas.bankID = rv_banks.id WHERE user='$user' AND currency = '$currency' AND rv_cuentas.category = 'BANK ACCOUNT' GROUP BY currency ORDER BY b DESC";
		$result = $mysqli->query($sql);
		$row = mysqli_fetch_assoc($result);
		$totalBalance = ($row['b'] + 0). " $currency";	
		
?>


<div class="kt-notification-v2">
	<h2>Disponible: <?php echo $totalBalance; ?></h2></br>
	<?php

		$sql = "SELECT *, SUM(balance) as b FROM rv_cuentas JOIN rv_banks ON rv_cuentas.bankID = rv_banks.id WHERE user='$user' AND currency = '$currency' AND rv_cuentas.category = 'BANK ACCOUNT' GROUP BY bankID ORDER BY b DESC";
		$result = $mysqli->query($sql);
		if ($result->num_rows > 0){
			while($row = mysqli_fetch_assoc($result)){
				
				$bid = $row['bankID'];
				
				
	?>
	<div class="dropdown">
		<a href="#" class="kt-notification-v2__item" data-toggle="dropdown">
			<div class="kt-notification-v2__item-icon ">
				<i class="la la-bank kt-font-success"></i>
			</div>
			<div class="kt-notification-v2__itek-wrapper">
				<div class="kt-notification-v2__item-title">
					<?php echo $row['bankName']; ?>
				</div>
				<div class="kt-notification-v2__item-desc">
					<?php $x = $row['b'];
							echo number_format($x,2,',','.');?>
					<span class="kt-widget1__number kt-font-warning"><?php 
					$sql = "SELECT SUM(Pago) as b FROM giros_sinprocesar JOIN rv_beneficiario ON giros_sinprocesar.idBeneficiary = rv_beneficiario.id JOIN rv_banks ON rv_banks.id = rv_beneficiario.bank WHERE (client_id = '$myclientid' OR admin='$myclientid') AND (estado='SIN PROCESAR' OR estado = 'INCIDENCIA' OR estado= 'VALIDANDO DATOS' OR estado = 'VALIDANDO PAGO') AND rv_banks.id = '$bid'";
					$result2 = $mysqli->query($sql);
					$row2 = mysqli_fetch_assoc($result2);
					     $y = $row2['b'];
						  echo number_format($y,2,',','.'); ?></span>
				</div>
				<div class="kt-notification-v2__item-desc">
					<span class="kt-widget1__number kt-font-info">Dif: <?php echo number_format($x-$y,2,',','.'); ?></span>
				</div>
			</div>
		</a>
		<div class="dropdown-menu dropdown-menu-xl" aria-labelledby="dropdownMenuButton">
			<div class="kt-notification-v2">
				<?php 
				
					$sql = "SELECT * FROM rv_cuentas WHERE user='$user' AND bankID = '$bid' AND currency = '$currency' AND category = 'BANK ACCOUNT' ORDER BY balance DESC";
					$result2 = $mysqli->query($sql);
					if ($result2->num_rows > 0){
						while($row2 = mysqli_fetch_assoc($result2)){
							
						
				?>
				<a href="#" class="kt-notification-v2__item">
					<div class="kt-notification-v2__item-icon">
						<i class="la la-bank kt-font-success"></i>
					</div>
					<div class="kt-notification-v2__itek-wrapper">
						<div class="kt-notification-v2__item-title">
							<?php echo $row2['alias']; ?>
						</div>
						<div class="kt-notification-v2__item-desc">
							<?php echo number_format($row2['balance'],2,',','.'); ?>
						</div>
					</div>
				</a>
				<?php }}?>
			</div>
		</div>
	</div>
	<?php }}?>
</div>