<?php

		include '../../php/conection.php';
		include '../../php/session.php';
			
			$final = array();
			$meta = array();
			$data = array();
			$value = array();
			
			
			$user = $_SESSION['id'];
			$result = $mysqli->query("SELECT * FROM login WHERE id='$user'");
			$row = mysqli_fetch_assoc($result);
			$client = $row['client'];	
			$permision = $row['privileges'];
			$agent = $row['Client_id'];			
			$order = "id ASC";
			$where = null;
				
			$and = 0;
				
			if (!empty($_POST['params'])){
				$params = $_POST['params'];
				foreach ($params as $key => $val) {
					
					$params[$key] = strtoupper(mysqli_real_escape_string($mysqli,$val));
					
				}
				
				
				if (!empty($params[0])){
					$search = $params[0];
					$where .= "WHERE (nombre LIKE '%%$search%%' OR category LIKE '%%$search%%' OR formato)";
					$and = 1;
				}
				
				if (!empty($params[1])){
					$status = $params[1];
					if ($and == 1){
						$where .= " AND UCASE(category)='$status'";
					}else{
						$where .= " WHERE UCASE(category)='$status'";
						$and = 1;
					}
					
					
				}
				if (!empty($params[2])){
					$status = $params[2];
					if ($and == 1){
						$where .= " AND UCASE(formato)='$status'";
					}else{
						$where .= " WHERE UCASE(formato)='$status'";
						$and = 1;
					}
					
					
				}
				
				
			}
			

	
			
			$sql = "SELECT * FROM productos $where ORDER BY $order LIMIT 1000";
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0){
				while($row = mysqli_fetch_assoc($result)){
					
					
					$value["Nombre"] = $row["nombre"];
					$value["Categoria"] = $row["category"];
					$value["Formato"] = $row["formato"];
					$value["UnidadXFormato"] = $row["unidadXformato"];
					$value["Stock"] = $row["stock"];		
					array_push($data, $value);
					
				}
			}
			
			$final['meta'] = $meta;
			$final['data'] = $data;	
			
			$json = json_encode($final, true);
			
			echo $json;
			
			

?>

