	
var completeFunctions = function () {

	// basic demo
	var DataTable = function(params) {
		
		var datatable = $('.kt-datatable').KTDatatable({
			// datasource definition
			data: {
				type: 'remote',
				source: {
					read: {
						url: 'clientes/php/jsondatatable.php',
						method:'POST',
						// sample custom headers
						params: {
								  params: params,
								},
						map: function(raw) {
							// sample data mapping
							var dataSet = raw;
							if (typeof raw.data !== 'undefined') {
								dataSet = raw.data;
							}
							return dataSet;
						},
					},
				},
				pageSize: 10,
				serverPaging: false,
				serverFiltering: false,
				serverSorting: true,
			},
			
			// layout definition
			layout: {
				scroll: true,
				footer: false,
			},
			// column sorting
			sortable: false,
			
			pagination: true,

			// columns definition
			columns: [
				{	
					field: 'Rut',
					title: 'Rut',
					autoHide: false,
				},
				{	
					field: 'RazonSocial',
					title: 'RazonSocial',
					autoHide: false,
				},
				{	
					field: 'Direccion',
					title: 'Direccion',
					autoHide: false,
				},
				{	
					field: 'Comuna',
					title: 'Comuna',
					autoHide: false,
				},
				{	
					field: 'Telefono',
					title: 'Telefono',
					autoHide: false,
				},
				{	
					field: 'NombreFantasia',
					title: 'NombreFantasia',
					autoHide: false,
				},
				{	
					field: 'Email',
					title: 'Email',
					autoHide: false,
				},
				{	
					field: 'Cpago',
					title: 'Cpago',
					autoHide: false,
				}],	
			rows : {
				autoHide: false,
			},
		});
	

	
	var GeneralButtons = function(){

	}
	

	
	
	datatable.on('kt-datatable--on-init', function() {

			});
	datatable.on('kt-datatable--on-layout-updated', function() {
					
					GeneralButtons();
			});
			
			
			
	}

		$('#kt_search').on('click', function(e) {
			e.preventDefault();
			var params = {};
			$('.kt-input').each(function() {
				var i = $(this).data('col-index');
				if (params[i]) {
					params[i] += '|' + $(this).val();
				}
				else {
					params[i] = $(this).val();
				}
			});
			localStorage.setItem("searchParams", JSON.stringify(params));
			$('#mytable').html('<div class="kt-datatable" id="ajax_data"></div>');
			console.log(params);
			DataTable(params);
		});
		
		
		$('#kt_reset').on('click', function(e) {
			e.preventDefault();
			localStorage.setItem("searchParams", JSON.stringify([]));
			$('.kt-search').each(function() {
				$(this).val('');
			});
			
		});
	
		return {
		// public functions
		init: function() {
			           
			var params = JSON.parse(localStorage.getItem("searchParams"));
			if (!Array.isArray(params) && !params.length){
				console.log(123);
				$('.kt-input').each(function() {
					var index = $(this).data('col-index');
					
					if (index == 5){
						var v = params[index].split("|");
						$('input[name="start"]').val(v[0]);
						$('input[name="end"]').val(v[1]);
					}else{
						$(this).val(params[index]);
					}
				});
			}
			
			console.log(params);
			DataTable(params);

		}
	};
}();



jQuery(document).ready(function() {
    completeFunctions.init();
});