<?php
	include '../../../admin/gmail/conect.php';
	include '../../php/conection.php';
	

	$error = null;
	
	//get form data
	$u = $_POST['email'];
	$p = $_POST['password'];
	$p2 = $_POST['password2'];
	
	if($p !== $p2){
		
		echo -2;
		return;
	}else{
		
		
		$checkmail = $mysqli->query("Select email FROM login WHERE email = '$u'");
		
		if($checkmail->num_rows > 0){
			
			echo -3;
			return;
			
		}else{
			
		//sanitize form data
		$u = $mysqli->real_escape_string($u);
		$p = $mysqli->real_escape_string($p);
		$p2 = $mysqli->real_escape_string($p2);
		
		//generate key
		$vkey = md5(time().$u);
		
		//insert account into the database
		$p = md5($p);
		$insert = $mysqli->query("INSERT INTO login(email, pas, vkey,verified,privileges) VALUES ('$u', '$p','$vkey',0,'USER')");
		
		if ($insert){
			//Send Email
			include 'confirmation-email.php';
			$to = $u;
			$subject = "Bienvenido a Remesafe! - Verificacion de Email";
			$mail->Username = 'remesafe56@gmail.com';
			$mail->Password = 'Q1w2e3r44*';
			$mail->setFrom('remesafe56@gmail.com', 'Remesafe');
			$mail->addAddress($u);     // Add a recipient
			$mail->isHTML(true);                                 
			$mail->Subject = $subject;
			$mail->Body =  $message;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
			
			if($mail->send()){
				echo 2;
				return;
			}else {
				
				echo -4;
				return;
			}
			
			
		}else{
			//echo $mysqli->error;
			echo -5;
			return;
		}			
		}
		

		
	}

echo $error;