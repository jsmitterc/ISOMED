"use strict";
// Class definition

var KTDatatableRemoteAjaxDemo = function() {

	var MessageDisplay = function(title, type){
	
					 Swal.fire({
					  toast: true,
					  position: 'top-end',
					  title: title,
					  timer: 3000,
					  showConfirmButton: false,
					  type: type,
					});
			
	};
	
	var ctx = document.getElementById('myChart').getContext('2d');
	var ctx2 = document.getElementById('myChart2').getContext('2d');
	var ctx3 = document.getElementById('myChart3').getContext('2d');
	var ctx4 = document.getElementById('myChart4').getContext('2d');


	 $.ajax({
	   url : 'dashboard/php/dashboardReport.php',
	   type : 'POST',
	   processData: false,  // tell jQuery not to process the data
	   contentType: false,  // tell jQuery not to set contentType

	   
	   success : function(data) {
			console.log(data);
			var obj = JSON.parse(data);
	
			var options = {
						 scales: {
							xAxes: [{
								gridLines: {
									display: false,
								}
							}],
							yAxes: [{
								gridLines: {
									display: false,
								}   
							}],         						},
					}
			var myLineChart = new Chart(ctx, {
				type: 'line',
				data: obj[0],
				options: options
			});
			var myLineChart = new Chart(ctx3, {
				type: 'line',
				data: obj[2],
				options: options
			});


			var myPieChart = new Chart(ctx2, {
				type: 'pie',
				data: obj[1],
				options: options
			});	
			
						var options = {
						       scales: {
									yAxes: [{
									  ticks: {
										beginAtZero: true,
										callback: function(value, index, values) {
										  if(parseInt(value) >= 1000){
											return '$' + value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
										  } else {
											return '$' + value;
										  }
										}
									  }
									}]
								  },
					}

			var myPieChart = new Chart(ctx4, {
							type: 'bar',
							data: obj[3],
							options: options
						});



			var numbers = obj[4];
			
			var p = numbers["positive"];
			var n = numbers["negative"];
			var t = p + n;
			
			$("span[name='p']").html(p);
			$("span[name='n']").html(n);
			$("span[name='t']").html(t);
			console.log(numbers);
		}});
		
		$('button[name=restaurantReport]').on('click', function() {
			(async () => {	
				 await Swal.fire({
				 
				  confirmButtonText: 'Next &rarr;',
				  showCancelButton: true,
				  title: 'Subir Reporte',
				  html: '<input type="file" name="file" id="archivo" class="form-control cc-exp">',
				  preConfirm: (result) => {
					var obj = result.value;
					console.log(obj);
					var file = $('#archivo')[0].files[0];
					if (file == undefined){
						Swal.showValidationMessage("Porfavor Ingresa un Archivo");
						return;
					}else if(file.type !== 'application/vnd.ms-excel' && file.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
						Swal.showValidationMessage("Solamente puedes subir archivos EXCEL","error");														 
						 return;
					}else{
						return true;
					}
				  },
				}).then((result) => {
				  if (result.value) {
					var obj = result.value;
					var file = $('#archivo')[0].files[0];
					var formData = new FormData();					
					formData.append('file', file);
					formData.append('bank', obj[0]);

						/*let timerInterval
								Swal.fire({
								  title: 'Procesando!',
								  html: 'Porfavor Esperar',
								  allowOutsideClick: false,
								  onBeforeOpen: () => {
									Swal.showLoading()
								  },
								  onClose: () => {
									clearInterval(timerInterval)
								  }
								});*/
						
						$.ajax({
						   url : 'dashboard/php/uploadRestaurantReport.php',
						   type : 'POST',
						   data : formData ,
						   processData: false,  // tell jQuery not to process the data
						   contentType: false,  // tell jQuery not to set contentType

						   
						   success : function(data) {
							   console.log(data);
							   var obj = JSON.parse(data);																	
								if (obj.Result){
								
									$("div[name='restaurantErrors']").html(obj.Errors);
								}
								
								MessageDisplay(obj.Message,obj.Type);
								
						   }
						});
						
				  }
				})
				
					
			})()
								
							
						
		});		
		
		var bankInfo = function (currency){

			var formData = new FormData();
			formData.append('currency', currency);

			 $.ajax({
			   url : 'dashboard/php/bankInfo.php',
			   type : 'POST',
			   data: formData,
			   processData: false,  // tell jQuery not to process the data
			   contentType: false,  // tell jQuery not to set contentType

			   
			   success : function(data) {
					console.log(data);
					$("#bankInfo").html(data);
						
				}});			
			
		}
		
		
		bankInfo('VES');

		$('select[name="bankCurrency"]').on('change', function f() {
			console.log(1212);
			var code = $(this).find('option:selected').val();
			bankInfo(code);
			
		});
	
	

	return {
		// public functions
		init: function() {
			



		},
	};
}();

jQuery(document).ready(function() {
	KTDatatableRemoteAjaxDemo.init();
	
	
	
});
