<?php

require ("g/vendor/autoload.php");
//Step 1: Enter you google account credentials

$g_client = new Google_Client();

$g_client->setClientId("740668099905-0khrhtlqb17a8iaj4fc5kf5jguts67nm.apps.googleusercontent.com");
$g_client->setClientSecret("LI1AmuUlrB_irFYLX76D0hTu");
$g_client->setRedirectUri("http://localhost/admin/login/auth.php");
$g_client->setScopes("email");
//Step 3 : Get the authorization  code
$code = isset($_GET['code']) ? $_GET['code'] : NULL;

//Step 4: Get access token
if(isset($code)) {

    try {

        $token = $g_client->fetchAccessTokenWithAuthCode($code);
        $g_client->setAccessToken($token);

    }catch (Exception $e){
        echo $e->getMessage();
    }




    try {
        $pay_load = $g_client->verifyIdToken();


    }catch (Exception $e) {
        echo $e->getMessage();
    }

} else{
    $pay_load = null;
}

if(isset($pay_load)){


    

}