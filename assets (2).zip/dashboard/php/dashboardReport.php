<?php

		include '../../php/conection.php';
		include '../../php/session.php';
			

			$graphs = array();
			
			$u = $_SESSION['id'];
			$result = $mysqli->query("SELECT * FROM login WHERE id='$u'");
			$row = mysqli_fetch_assoc($result);
			$client = $row['client'];	
			$permision = $row['privileges'];
			$agent = $row['Client_id'];
			$where = null;	
			$date = (new DateTime('now', new DateTimezone('America/Caracas')))->format("Y/m/d");	
			
			
			if ($client == '001' && $agent == '159'){
				return;
			}


			$where = null;
			
			
			if ($client == "701" || $permision == "CLIENTE"){
				$where .= " AND Agente='$agent'";
			}
			
		$result = $mysqli->query("SELECT data FROM rv_exchange_rate ORDER BY id DESC LIMIT 1;");
		$row = mysqli_fetch_assoc($result);
		$fx = json_decode($row['data'], TRUE);
		
		$currencyBase = array('USD', 'GBP', 'CLP','VES','PEN');
		
		$result = $mysqli->query("SELECT data FROM rv_stockprices ORDER BY id DESC LIMIT 1;");
		$row = mysqli_fetch_assoc($result);
		$stocks = json_decode($row['data'], TRUE);	

			/*GRAFICO 1*/
			$data = array();
			$data['labels'] = array();
			$data['datasets'] = array();
			$var =  $d = array();
			$var['label'] = "Giros últimos 6 meses";
			$d['label'] = "Pronóstico";
			$var['data'] = $d['data'] = array();
			$var['backgroundColor'] = "rgba(255, 206, 86, 1)";
			$dayNum = strtolower(date("d",strtotime($date)));
			$dayNum = intval($dayNum);
			$sql = "SELECT COUNT(*) as c, Month(Fecha) as m, Year(Fecha) as y FROM giros_sinprocesar WHERE (client_id='$client' OR admin='$client') AND estado != 'ANULADO' AND Fecha > DATE_SUB(now(), INTERVAL 12 MONTH) $where GROUP BY Year(Fecha), Month(Fecha)";
			$result = $mysqli->query($sql);
			$i = 1;
			$n = $result->num_rows;
			if ($result->num_rows > 0){
				$count = $result->num_rows;
				while($row = mysqli_fetch_assoc($result)){
					
					
					array_push($data['labels'],$row['m']."-".$row['y']);
					array_push($var['data'],$row['c']);
					
					
					
					if ($i == $n){
						$days = date("t");
						array_push($d['data'],round($row['c'] / $dayNum * $days,0));
					}else{
						array_push($d['data'],0);
					}
					
					++$i;
				}
			}
			
			array_push($data['datasets'],$var);
			array_push($data['datasets'],$d);
			
			
			
			array_push($graphs,$data);

			/*GRAFICO 2*/
			$data = array();
			$data['labels'] = array();
			$data['datasets'] = array();
			$var = array();
			$var['label'] = "Volumen";
			$var['data'] = array();
			$var['backgroundColor'] = array();
			$sql = "SELECT currency,SUM(Dolares ) as c, SUM(Pago / dayRate ) as c2 ,client_id,dayRateCurrency,dayRate FROM giros_sinprocesar WHERE (client_id='$client' OR admin='$client') AND Date(Fecha) = '$date' AND estado != 'ANULADO' $where GROUP BY currency,client_id";
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0){
				$count = $result->num_rows;
				while($row = mysqli_fetch_assoc($result)){
					
					if ($row['client_id'] !== $client && $row['dayRateCurrency'] !== $row['currency']){
						$total = round($row['c2'],2);
						$currency = $row['dayRateCurrency'];
					}else{
						$total = $row['c'];
						$currency = $row['currency'];
					}
					
					$one = mt_rand(100, 255);
					$two = mt_rand(1, 255);
					$three = mt_rand(1, 255);
					$rgba = "rgba($one,$two,$three,1)";
					
					array_push($data['labels'],$currency);
					array_push($var['data'],$total);
					array_push($var['backgroundColor'],$rgba);
				}
			}
			array_push($data['datasets'],$var);
			
			array_push($graphs,$data);

			
			/*GRAFICO 3*/
			$data = array();
			$data['labels'] = array();
			$data['datasets'] = array();
			$var = array();
			$var['label'] = "Volumen los ultimos 7 dias";
			$var['data'] = array();
			$var['backgroundColor'] = "rgba(255, 55, 205, 1)";
			$sql = "SELECT currency, SUM(Dolares) as c, DAY(Fecha) as m, MONTH(Fecha) as y FROM giros_sinprocesar WHERE client_id='$client' AND Fecha > DATE_SUB(DATE(now()), INTERVAL 7 DAY) $where GROUP BY DAY(Fecha),currency";
			
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0){
				$count = $result->num_rows;
				while($row = mysqli_fetch_assoc($result)){
					
					if (in_array($row['currency'], $data['labels'])){
						$index = array_search ($row['currency'], $data['labels']);
						$var['data'][$index] += $row['c'];
					}else{
						array_push($data['labels'],$row['m']."-".$row['y']);
						array_push($var['data'],$row['c']);
					}
					
					
				}
			}
			
			
			
			
			array_push($data['datasets'],$var);
			
			array_push($graphs,$data);
			
			/*GRAFICO 4*/
			$data = array();
			$data['labels'] = array();
			$data['datasets'] = array();
			$var = array();
			$var['label'] = "Distribucion de Activos";
			$var['data'] = $var['percentage'] =  array();
			
			$var['backgroundColor'] = "rgba(50, 45, 100, 1)";
			$sql = "SELECT SUM(balance) as b, category, currency FROM `rv_cuentas` WHERE user = $u and active = 1 and category != 'NULL' and balance != 0 group by category, currency";
			$x = array();
			$x["positive"] = $x["negative"] = 0;
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0){
				$count = $result->num_rows;
				while($row = mysqli_fetch_assoc($result)){
					$curr = $row['currency'];
					
						$rate = $fx['CLP'];
					if ($row['category'] !== "STOCK"){
						
						$rate2 = $fx[$curr];
						$conversion = $rate2 / $rate;
						$val = $row['b'] / $conversion;
					}else{
						$rate2 = $stocks[$curr];
						$val = $rate2 * $row['b'] * $rate;
					}
					
					if ($row['category'] == "CREDIT CARD" || $row['category'] == "LOAN"){
						$val = $val * -1;
					}
					
					
					
					
					$val = round($val,0);
					
					if ($val > 0){
						$x["positive"] += $val; 
					}else{
						$x["negative"] += $val; 
					}
					
					
					if (in_array($row['category'], $data['labels'])){
						$index = array_search ($row['category'], $data['labels']);
						$var['data'][$index] += $val;
					}else{
						array_push($data['labels'],$row['category']);
						array_push($var['data'],$val);
					}
					
					
				}
			}
			
			
			
			$sql = "SELECT SUM(cost * quantity) as b FROM `inventory`";
			$result = $mysqli->query($sql);
			$row = mysqli_fetch_assoc($result);
			$products = $row['b'];
			$x["positive"] += $products; 
			array_push($data['labels'],"INVENTORY");
			array_push($var['data'],$products);
			//rsort($var['data']);
			array_push($data['datasets'],$var);
			$tcash = $x['positive'] - $x['negative'];
			array_push($graphs,$data);
			array_push($graphs,$x);
		

			
			
			$json = json_encode($graphs, true);
			echo $json;
			
			
			

?>

