<?php 
		
	include 'conection.php';
	function sessionStart($lifetime, $path, $domain, $secure, $httpOnly){
		//session_set_cookie_params($lifetime, $path, $domain, $secure, $httpOnly);
		session_start(); 
	}
			 
	sessionStart(0,'/','localhost',false,true);

  if (!isset($_SESSION['u_email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: ../login');
  }
  if (isset($_GET['logout'])) {
	  
	  $user = $_SESSION['id'];
  	session_destroy();
  	unset($_SESSION['username']);
	
  	header("location: ../login");
	return;
  }
  
  $idletime=36000;//after 60 seconds the user gets logged out
  
if (time()-$_SESSION['timestamp']>$idletime){
	
	$user = $_SESSION['id'];	
	$sql = "UPDATE login SET linea='0'WHERE id='$user' ";
	$mysqli->query($sql);
    session_destroy();
    session_unset();

								
								
	header("location: ../login");
}else{
    $_SESSION['timestamp']=time();



}
//on session creation
$_SESSION['timestamp']=time();
  
  
  
?>