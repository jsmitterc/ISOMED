<?php require ("g/vendor/autoload.php");
//Step 1: Enter you google account credentials

$g_client = new Google_Client();

$g_client->setClientId("740668099905-0khrhtlqb17a8iaj4fc5kf5jguts67nm.apps.googleusercontent.com");
$g_client->setClientSecret("LI1AmuUlrB_irFYLX76D0hTu");
$g_client->setRedirectUri("http://localhost/admin/login/googlelog.php");
$g_client->setScopes("email");

//Step 3 : Get the authorization  code
$code = isset($_GET['code']) ? $_GET['code'] : NULL;
//Step 4: Get access token
if(isset($code)) {

    try {

        $token = $g_client->fetchAccessTokenWithAuthCode($code);
        $g_client->setAccessToken($token);

    }catch (Exception $e){
        echo $e->getMessage();
    }




    try {
        $pay_load = $g_client->verifyIdToken();


    }catch (Exception $e) {
        echo $e->getMessage();
    }

} else{
    $pay_load = null;
}

if(isset($pay_load)){
	
	
	if ($pay_load['email_verified'] == true){
				
		require '../conection.php';
		$u = $pay_load['email'];
		$p = $pay_load['sub'];
		
		
								$sql = "SELECT * FROM login WHERE email='$u'";
								$result = mysqli_query($mysqli, $sql);
								$resultCheck = mysqli_num_rows($result);
								if ($resultCheck == 0 ){
									
								$insert = $mysqli->query("INSERT INTO login(email, pas, vkey,verified) VALUES ('$u', '$p','',1)");
	
								}
		

				session_start();
							
								
								$sql = "SELECT * FROM login WHERE email='$u'";
								$result = mysqli_query($mysqli, $sql);
								$resultCheck = mysqli_num_rows($result);
								if ($resultCheck < 1 ){
									
									header("Location: ../login?error=2");
									exit();
									
								} else{
									
									if ($row = mysqli_fetch_assoc($result)){
										
			
											
											//log in the user here
										$_SESSION['name'] = $row['name'];
										$_SESSION['apellido'] = $row['apellido'];
										$_SESSION['u_email'] = $row['email'];
										$_SESSION['id'] = $row['id'];
										$_SESSION['timestamp'] = time ();
										$user = $row['id'];
										$date = new DateTime('now', new DateTimezone('America/Caracas'));
										$fecha = $date->format("Y/m/d H:i:s");
										$sql = "UPDATE login SET linea='1', tiempoingreso='$fecha' WHERE id='$user' ";
										$mysqli->query($sql);

										
										header("Location: ../index.php");
									
										
											exit();
										
										}
									}
								
				
			
			
	
		
	}else{
		
		
		header('location: ../login?error=4');
	}


    

}


