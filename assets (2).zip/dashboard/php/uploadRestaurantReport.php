<?php

	include '../../php/functions.php';
	include '../../php/conection.php';
	include '../../php/session.php';
						
					$file = $_FILES['file'];
					$info = $_FILES['file']['name'];

					$user = $_SESSION['id'];	
					$result = $mysqli->query("SELECT * FROM login WHERE id='$user'");
					$row = mysqli_fetch_assoc($result);
					$myclientid = $row['client'];					






						require'../../../admin/Classes/PHPExcel/IOFactory.php';

		
						$objPHPExcel = PHPExcel_IOFactory::load($_FILES['file']['tmp_name']);
				
						$objPHPExcel->setActiveSheetIndex(0);
						
						$numrows = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();
						
						$fecha = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,2)->getValue();
						$fecha =  date("Y-m-d", strtotime($fecha));
						$accountName1 = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,3)->getValue();
						$sale = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,3)->getValue();
						$currency = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,5)->getValue();
						$errors = null;
						$result = $mysqli->query("SELECT * FROM rv_cuentas WHERE user='$user' AND alias ='$accountName1' AND active=1 LIMIT 1");
						if ($result->num_rows > 0){
							$row = mysqli_fetch_assoc($result);
							$account1 = $row['code'];
							$result = $mysqli->query("SELECT * FROM rv_transaction WHERE client='$myclientid' AND creditacc ='$account1' AND credit='$sale' AND Date(fecha) = '$fecha' LIMIT 1");
							if ($result->num_rows == 0){
								$val = trans_entre_cuentas($mysqli,$myclientid, 0, $sale, 0, $account1, $fecha, "VENTA","Ventas $fecha","VENTA");
								
								for ($i = 6; $i <= $numrows ; $i++){
							
								$recieve = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$i)->getValue();
								if ($recieve == "Total"){
									break;
								}
							
									
									$recieveAmount1 = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$i)->getValue();
									$recieveAmount2 = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$i)->getValue();
									$result = $mysqli->query("SELECT * FROM rv_cuentas WHERE user='$user' AND alias ='$recieve' LIMIT 1");
									if ($result->num_rows == 0){
										$errors .= "Transaccion no realizada: Cuenta $recieve no existe. Porfavor ejecutar manualmente</br>";
										continue;
									}
									$row = mysqli_fetch_assoc($result);
									$account2 = $row['code'];
									$currency2 = $row['currency'];
									
									if ($currency == $currency2){
										$recieveAmount2 = $recieveAmount1;
									}
									
									trans_entre_cuentas($mysqli,$myclientid, $recieveAmount1, $recieveAmount2, $account1, $account2,$fecha, "TRANSFERENCIA","Traspaso de $accountName1 a $recieve","PAGO");
									
								}														
								$completed['Result'] = true;
								$completed['Type'] = "success";
								$completed['Errors'] = $errors;
								$completed['Message'] = "Ventas ingresadas exitosamente!";
								echo json_encode($completed);					
								return;
							}else{
								$completed['Result'] = false;
								$completed['Type'] = "error";
								$completed['Message'] = "Este reporte ya ha sido ingresado";
								echo json_encode($completed);					
								return;
							}
						}else{
							$completed['Result'] = false;
							$completed['Type'] = "error";
							$completed['Message'] = "No existe cuenta para ingresar";
							echo json_encode($completed);					
							return;
						}
						
						


					
						
								
			
					
	
	
?>