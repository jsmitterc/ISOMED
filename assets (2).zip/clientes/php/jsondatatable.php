<?php

		include '../../php/conection.php';
		include '../../php/session.php';
			
			$final = array();
			$meta = array();
			$data = array();
			$value = array();
			
			
			$user = $_SESSION['id'];
			$result = $mysqli->query("SELECT * FROM login WHERE id='$user'");
			$row = mysqli_fetch_assoc($result);
			$client = $row['client'];	
			$permision = $row['privileges'];
			$agent = $row['Client_id'];			
			$order = "id ASC";
			$where = null;
				
			$and = 0;
				
			if (!empty($_POST['params'])){
				$params = $_POST['params'];
				foreach ($params as $key => $val) {
					
					$params[$key] = strtoupper(mysqli_real_escape_string($mysqli,$val));
					
				}
				
				
				if (!empty($params[0])){
					$search = $params[0];
					$where .= "WHERE (rut LIKE '%%$search%%' OR razonSocial LIKE '%%$search%%' OR direccion LIKE '%%$search%%' OR comuna LIKE '%%$search%%'
								OR telefono LIKE '%%$search%%' OR nombreFantasia LIKE '%%$search%%' OR email LIKE '%%$search%%'
									OR contacto LIKE '%%$search%%' OR cpago LIKE '%%$search%%')";
					$and = 1;
				}
				
				if (!empty($params[1])){
					$status = $params[1];
					if ($and == 1){
						$where .= " AND UCASE(comuna)='$status'";
					}else{
						$where .= " WHERE UCASE(comuna)='$status'";						
					}
					
					
				}
				
				
			}
			

	
			
			$sql = "SELECT * FROM clientes $where ORDER BY $order LIMIT 1000";
			$result = $mysqli->query($sql);
			if ($result->num_rows > 0){
				while($row = mysqli_fetch_assoc($result)){
					
					
					$value["Rut"] = $row["rut"];
					$value["RazonSocial"] = $row["razonSocial"];
					$value["Direccion"] = $row["direccion"];
					$value["Comuna"] = $row["comuna"];
					$value["Telefono"] = $row["telefono"];
					$value["NombreFantasia"] = $row["nombreFantasia"];
					$value["Email"] = $row["email"];
					$value["Cpago"] = $row["cPago"];			
					array_push($data, $value);
					
				}
			}
			
			$final['meta'] = $meta;
			$final['data'] = $data;	
			
			$json = json_encode($final, true);
			
			echo $json;
			
			

?>

