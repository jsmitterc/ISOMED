<?php

			
			
			$user = $_SESSION['id'];
			$result = $mysqli->query("SELECT * FROM login WHERE id='$user'");
			$row = mysqli_fetch_assoc($result);
			
			
			/*$sql = "SELECT Agente FROM giros_sinprocesar WHERE (client_id='$client' OR admin='$client') $agent GROUP BY Agente ORDER BY Agente ASC";			
			$result = $mysqli->query($sql);
			
			if ($result->num_rows >0){
					while($row = mysqli_fetch_assoc($result)){
						$agentOptions .= '<option value="'.$row['Agente'].'">'.$row['Agente'].'</option>';
					}
			}
			
			if ($client == "701" || $permision == "CLIENTE"){
				$agent = " AND Client_id = '$agente'";
			}else{
				$agent = "";
			}
			
			$sql = "SELECT * FROM login WHERE client='$client' $agent ORDER BY id ASC";	
			$result = $mysqli->query($sql);
			
			if ($result->num_rows >0){
					while($row = mysqli_fetch_assoc($result)){
						$uploadAgent .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
					}
			}
			*/
			
			
			
?>

						<!-- begin:: Content -->
						<div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
							<div class="kt-portlet kt-portlet--mobile">
								<div class="kt-portlet__head kt-portlet__head--lg">
									<div class="kt-portlet__head-label">
										<span class="kt-portlet__head-icon">
											<i class="kt-font-brand flaticon2-line-chart"></i>
										</span>
										<h3 class="kt-portlet__head-title">
											Clientes
										</h3>
									</div>
								</div>
								<div class="kt-portlet__body">

									<!--begin: Search Form -->
									<form class="kt-form kt-form--fit kt-margin-b-20">
										<div class="row kt-margin-b-20">
											<div class="col-lg-3 kt-margin-b-10-tablet-and-mobile">
												<label>Palabra Clave:</label>
												<input type="text" class="form-control kt-input kt-search" placeholder="E.g: 4590" data-col-index="0">
											</div>
											<div class="col-lg-3 kt-margin-b-10-tablet-and-mobile">
												<label>Comuna:</label>
												<select class="form-control kt-input kt-search" data-col-index="1">
													<option value="">Elegir</option>
													<?php 			
														$sql = "SELECT comuna FROM clientes GROUP BY comuna ORDER BY comuna ASC";	
														$result = $mysqli->query($sql);
														
														if ($result->num_rows >0){
																while($row = mysqli_fetch_assoc($result)){
																	
									
																	echo '<option value="'.$row['comuna'].'">'.$row['comuna'].'</option>';
																}
														}
													?>
												</select>
											</div>
										</div>
										<div class="kt-separator kt-separator--md kt-separator--dashed"></div>
										<div class="row">
											<div class="col-lg-6">
												<button type="button" class="btn btn-primary btn-brand--icon" id="kt_search">
													<span>
														<i class="la la-search"></i>
														<span>Search</span>
													</span>
												</button>
												&nbsp;&nbsp;
												<button type="button" class="btn btn-secondary btn-secondary--icon" id="kt_reset">
													<span>
														<i class="la la-close"></i>
														<span>Reset</span>
													</span>
												</button>
											</div>
										</div>
									</form>

									<!--begin: Datatable -->
									<div id="mytable">
										<div class="kt-datatable" id="ajax_data"></div>
									</div>
									<!--end: Datatable -->
								</div>
							</div>
						</div>

						<!-- end:: Content -->

						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog modal-xl" role="document">
							<div class="modal-content" id="modalContent">
							</div>
						  </div>
						</div>	
						<!-- end:: Modal -->
						<!-- Modal -->
						<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
						  <div class="modal-dialog modal-lg" role="document">
							<div class="modal-content" id="modalContent2">
							</div>
						  </div>
						</div>	
						<!-- end:: Modal -->
