<?php$DB_HOST = "localhost";$DB_USER = "root";$DB_DATABASE = "ISOMED";$DB_PASS = "";$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_DATABASE);if(mysqli_connect_error()){echo 'Conection Failed: ', mysqli_connect_error();exit();}$mysqli2 = new mysqli("localhost", "root", "", "restaurant_admin");if(mysqli_connect_error()){echo 'Conection Failed: ', mysqli_connect_error();exit();}



?>