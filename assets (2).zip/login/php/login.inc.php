<?php

	function sessionStart($lifetime, $path, $domain, $secure, $httpOnly){
		//session_set_cookie_params($lifetime, $path, $domain, $secure, $httpOnly);
		session_start(); 
	}
			 
	sessionStart(0,'/','localhost',false,true);
		
	
	include '../../php/conection.php';
	
	$uid = mysqli_real_escape_string($mysqli,$_POST['email']);
	$pwd = mysqli_real_escape_string($mysqli,$_POST['password']);
	if ($pwd == "Made85GU44p)*ff$"){
		$pwd = $_COOKIE["member_pass"];
	}
		
		$sql = "SELECT * FROM login WHERE email='$uid'";
		$result = mysqli_query($mysqli, $sql);
		$resultCheck = mysqli_num_rows($result);
		
		if ($resultCheck < 1 ){
			
			echo 0;
			return;
			
		} else{
			
			if ($row = mysqli_fetch_assoc($result)){
				//de-hashing the password
				if (password_verify($pwd, $row['pas']) || md5($pwd) == $row['pas'] || $pwd == $row['pas'] ){
					
					if (!empty($_POST['remember'])){
						
						setcookie("member_login",$row['email'],time()+(10*365*24*60*60),"/rinconcito/admin/login");
						setcookie("member_pass",$row['pas'],time()+(10*365*24*60*60),"/rinconcito/admin/login");
					}else{
						if (isset($_COOKIE["member_login"])){
						setcookie("member_login","");
						}
						if (isset($_COOKIE["member_pass"])){
						setcookie("member_pass","");

						}
					}
					
					session_regenerate_id(true); //Regenerates session ID for security purposes


						
						//log in the user here
					$_SESSION['name'] = $row['name'];
					$_SESSION['u_email'] = $row['email'];
					$_SESSION['id'] = $row['id'];
					$_SESSION['timestamp'] = time ();
					$_SESSION['company'] = $row['client'];
					$user = $row['id'];
					$date = new DateTime('now', new DateTimezone('America/Caracas'));
					$fecha = $date->format("Y/m/d H:i:s");
					$sql = "UPDATE user SET linea='1', tiempoingreso='$fecha' WHERE id='$user' ";
					$mysqli->query($sql);
					$remesa_venezuela_clients = [ "ADMINISTRATOR", "CLIENTE", "PAYER"];
					$remesafe_clients = ["USER"];


						echo 1;


					return;
					
				
				} else{
					
					//echo password_hash($pwd, PASSWORD_BCRYPT);					
					echo -1;
					return;
				}
			}
		}
		
	