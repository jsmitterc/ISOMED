"use strict";

// Class Definition
var KTLoginV1 = function () {
	var login = $('#kt_login');

	var showErrorMsg = function(form, type, msg) {
        var alert = $('<div class="alert alert-bold alert-solid-' + type + ' alert-dismissible" role="alert">\
			<div class="alert-text" style="color:#ffffff">'+msg+'</div>\
			<div class="alert-close">\
                <i class="flaticon2-cross kt-icon-sm" data-dismiss="alert"></i>\
            </div>\
		</div>');

        form.find('.alert').remove();
        alert.prependTo(form);
        KTUtil.animateClass(alert[0], 'fadeIn animated');
    }
	
    var displayForgotForm = function() {
        login.removeClass('kt-login--signin');
        login.removeClass('kt-login--signup');

        login.addClass('kt-login--forgot');
        //login.find('.kt-login--forgot').animateClass('flipInX animated');
        KTUtil.animateClass(login.find('.kt-login__forgot')[0], 'flipInX animated');

    }
    var displaySignInForm = function() {
        login.removeClass('kt-login--forgot');
        login.removeClass('kt-login--signup');

        login.addClass('kt-login--signin');
        KTUtil.animateClass(login.find('.kt-login__signin')[0], 'flipInX animated');
        //login.find('.kt-login__signin').animateClass('flipInX animated');
    }
	
    var handleFormSwitch = function() {
        $('#kt_login_forgot').click(function(e) {
            e.preventDefault();
            displayForgotForm();
        });

        $('#kt_login_forgot_cancel').click(function(e) {
            e.preventDefault();
            displaySignInForm();
        });

        $('#kt_login_signup').click(function(e) {
            e.preventDefault();
            displaySignUpForm();
        });

        $('#kt_login_signup_cancel').click(function(e) {
            e.preventDefault();
            displaySignInForm();
        });
    }

	// Private Functions
	var handleSignInFormSubmit = function () {
		$('#kt_login_signin_submit, #kt_login_signup_submit').click(function (e) {
			e.preventDefault();

			var btn = $(this);
			var form = $('#kt_login_form');
		if (this.id == 'kt_login_signin_submit'){
			form.validate({
				rules: {
					email: {
						required: true
					},
					password: {
						required: true
					}
				}
			});
			
			var url = 'login/php/login.inc.php';
			
		}else{
			form.validate({
				rules: {
					email: {
						required: true
					},
					password: {
						required: true
					},
					password2: {
						required: true
					}
				}
			});	
			
			var url = 'login/php/signup.php';
		}

			if (!form.valid()) {
				return;
			}

			KTApp.progress(btn[0]);

			setTimeout(function () {
				KTApp.unprogress(btn[0]);
			}, 2000);
			
			form.ajaxSubmit({
				url: url,
				success: function (response, status, xhr, $form) {									
					console.log(response);
					// similate 2s delay
					setTimeout(function () {
						KTApp.unprogress(btn[0]);
						
						if (response == 1){
						
						window.location.replace("dashboard");
						}else if (response == 3){
							window.location.replace("../login");
						}else if (response == 0 || response == -1 ){
							showErrorMsg(form, 'danger', 'Correo o contraseña incorrecta. Vuelve a intentar.');
						}else if (response == -2){
							showErrorMsg(form, 'danger', 'Contraseñas no coinciden. Vuelve a intentar.');
						}else if (response == -3){
							showErrorMsg(form, 'danger', 'Correo ya registrado!');
						}else if (response == 2){
							$.notify({
								message: 'Correo Enviado con éxito! Porfavor confirmar para continuar' 
							},{
								type: 'Success'
							});
						}
						
					}, 2000);
					
					
				}
			});
		});
	}
    var handleForgotFormSubmit = function() {
        $('#kt_login_forgot_submit').click(function(e) {
            e.preventDefault();

            var btn = $(this);
            var form = $(this).closest('form');

            form.validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    }
                }
            });

            if (!form.valid()) {
                return;
            }

            btn.addClass('kt-spinner kt-spinner--right kt-spinner--sm kt-spinner--light').attr('disabled', true);

            form.ajaxSubmit({
                url: 'login/php/submit_forgot_password.php',
                success: function(response, status, xhr, $form) {
                	// similate 2s delay
                	setTimeout(function() {
                		btn.removeClass('kt-spinner kt-spinner--right kt-spinner--sm kt-spinner--light').attr('disabled', false); // remove
	                    form.clearForm(); // clear form
	                    form.validate().resetForm(); // reset validation states

	                    // display signup form
	                    displaySignInForm();
	                    var signInForm = login.find('.kt-login__signin form');
	                    signInForm.clearForm();
	                    signInForm.validate().resetForm();

	                    showErrorMsg(signInForm, 'success', 'Excelente! Enviamos las instrucciones para recuperar la constraseña a tu correo.');
                	}, 2000);
                }
            });
        });
    }

	// Public Functions
	return {
		// public functions
		init: function () {
			handleSignInFormSubmit();
			handleFormSwitch();
			handleForgotFormSubmit();
		}
	};
}();

// Class Initialization
jQuery(document).ready(function () {
	KTLoginV1.init();
	
	var url_string = window.location.href
	var url = new URL(url_string);
	var c = url.searchParams.get("vkey");
	if (c !== null){
			var formData = new FormData();
			formData.append('vkey', c);
		
			$.ajax({
			   url : 'login/php/confirmvkey.php',
			   type : 'POST',
			   data : formData,
			   processData: false,  // tell jQuery not to process the data
			   contentType: false,  // tell jQuery not to set contentType

			   
			   success : function(data) {
				   
				   if (data == 1){
							$.notify({
								message: 'Correo Electrónico confirmado! Puedes ingresar' 
							},{
								type: 'Success'
							});					   
				   }else if (data == -1){
							$.notify({
								message: 'Error. Verificacion no confirmada' 
							},{
								type: 'Danger'
							});					   
				   }

			   }
														   
			});	
	}
});
