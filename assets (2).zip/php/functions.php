<?php


function checkaccount($account, $client, $mysqli) {
    
			$sql = "SELECT * FROM blacklist WHERE client='$client' AND account='$account'";
			$result = $mysqli->query($sql);
			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0){
			return 1;
			}
}


function trans_entre_cuentas($mysqli,$client, $debit, $credit, $debacc, $credacc, $fecha, $ref,$descripcion,$category,$entity = null) {
	
				if ($entity == null){
					$entity = 0;
				}

				$sql = "UPDATE rv_cuentas SET balance = balance - '$debit' WHERE code='$debacc' AND ((client = '$client' AND class1='1') OR (client != '$client' AND class1='2') OR (class1='3' AND client='$client'))";
				$result = $mysqli->query($sql);
				
				$sql = "UPDATE rv_cuentas SET balance = balance + '$debit' WHERE code='$debacc' AND ((client = '$client' AND class1='2') OR (client != '$client' AND class1='1'))";
				$result = $mysqli->query($sql);	

				$sql = "UPDATE rv_cuentas SET balance = balance + '$credit' WHERE code='$credacc' AND ((client = '$client' AND class1='1') OR (client != '$client' AND class1='2') OR (class1='3' AND client='$client'))";
				$result = $mysqli->query($sql);

				$sql = "UPDATE rv_cuentas SET balance = balance - '$credit' WHERE code='$credacc' AND ((client = '$client' AND class1='2') OR (client != '$client' AND class1='1'))";
				$result = $mysqli->query($sql);	
				
			


			$sql = "SELECT * FROM rv_cuentas WHERE code='$debacc'";
			$result = $mysqli->query($sql);
			$row = mysqli_fetch_assoc($result);
			$debbalance = $row['balance'];
			$sql = "SELECT * FROM rv_cuentas WHERE code='$credacc'";
			$result = $mysqli->query($sql);
			$row = mysqli_fetch_assoc($result);
			$credbalance = $row['balance'];
				
	
			if ($debit == 0){
				
				$debbalance = 0;
			}else if ($credit == 0){
				
				$credbalance = 0;
			}
					
			$sql = "INSERT INTO rv_transaction (client, name, debit, credit, debitacc, creditacc, fecha, balancedebit, balancecredit,description,category,company) VALUE ( '$client', '$ref', '$debit', '$credit', '$debacc' , '$credacc' , '$fecha', '$debbalance', '$credbalance','$descripcion','$category','$entity');";
			$result = $mysqli->query($sql);
			
			
			if (!$result){
				
				return $sql;
			}
			$result = $mysqli->query("SELECT LAST_INSERT_ID() as last;");
			
			if ($result){
				$row = mysqli_fetch_assoc($result);
				return $row['last'];				
			}

			
			
			
			
			

			
			
}

function reverse_trans_entre_cuentas($mysqli,$tid) {
	
				if ($entity == null){
					$entity = 0;
				}

				$sql = "UPDATE rv_cuentas SET balance = balance - '$debit' WHERE code='$debacc' AND ((client = '$client' AND class1='1') OR (client != '$client' AND class1='2') OR (class1='3' AND client='$client'))";
				$result = $mysqli->query($sql);
				
				$sql = "UPDATE rv_cuentas SET balance = balance + '$debit' WHERE code='$debacc' AND ((client = '$client' AND class1='2') OR (client != '$client' AND class1='1'))";
				$result = $mysqli->query($sql);	

				$sql = "UPDATE rv_cuentas SET balance = balance + '$credit' WHERE code='$credacc' AND ((client = '$client' AND class1='1') OR (client != '$client' AND class1='2') OR (class1='3' AND client='$client'))";
				$result = $mysqli->query($sql);

				$sql = "UPDATE rv_cuentas SET balance = balance - '$credit' WHERE code='$credacc' AND ((client = '$client' AND class1='2') OR (client != '$client' AND class1='1'))";
				$result = $mysqli->query($sql);	
				
			


			$sql = "SELECT * FROM rv_cuentas WHERE code='$debacc'";
			$result = $mysqli->query($sql);
			$row = mysqli_fetch_assoc($result);
			$debbalance = $row['balance'];
			$sql = "SELECT * FROM rv_cuentas WHERE code='$credacc'";
			$result = $mysqli->query($sql);
			$row = mysqli_fetch_assoc($result);
			$credbalance = $row['balance'];
				
	
			if ($debit == 0){
				
				$debbalance = 0;
			}else if ($credit == 0){
				
				$credbalance = 0;
			}
					
			$sql = "INSERT INTO rv_transaction (client, name, debit, credit, debitacc, creditacc, fecha, balancedebit, balancecredit,description,category,company) VALUE ( '$client', '$ref', '$debit', '$credit', '$debacc' , '$credacc' , '$fecha', '$debbalance', '$credbalance','$descripcion','$category','$entity');";
			$result = $mysqli->query($sql);
			
			
			if (!$result){
				
				return $sql;
			}
			$result = $mysqli->query("SELECT LAST_INSERT_ID() as last;");
			
			if ($result){
				$row = mysqli_fetch_assoc($result);
				return $row['last'];				
			}

			
			
			
			
			

			
			
}


function checktransaction($monto ,$cuenta1,$fecha, $client, $mysqli) {


			if ($monto > 0){
				
				$pago = abs($monto);
			$sql = "SELECT * FROM rv_transaction WHERE client='$client' AND credit='$pago'  AND creditacc='$cuenta1' AND DATE(fecha)='$fecha'";
				
				
				
			}else if ($monto < 0){
				
				$pago = abs($monto);

			$sql = "SELECT * FROM rv_transaction WHERE client='$client' AND debit='$pago'  AND debitacc='$cuenta1' AND DATE(fecha)='$fecha'";
				
			}			
		
			$result = $mysqli->query($sql);
			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0){
				
							if ($monto > 0){
				
								$pago = abs($monto);
									$sql = "UPDATE rv_transaction SET conciled = 1 WHERE client='$client' AND credit='$pago'  AND creditacc='$cuenta1' AND conciled iS NULL";
								
								
								
							}else if ($monto < 0){
								
								$pago = abs($monto);

							$sql = "UPDATE rv_transaction SET conciled = 1 WHERE client='$client' AND debit='$pago'  AND debitacc='$cuenta1' AND conciled iS NULL";
								
							}
			$result = $mysqli->query($sql);	
			return 1;
			}
}

function checkpasivo($monto ,$cuenta1,$fecha, $client, $mysqli) {


			if ($monto < 0){
				
				$pago = abs($monto);
			$sql = "SELECT * FROM rv_transaction WHERE client='$client' AND credit='$pago'  AND creditacc='$cuenta1' AND DATE(fecha)='$fecha'";
				
				
				
			}else if ($monto > 0){
				
				$pago = abs($monto);

			$sql = "SELECT * FROM rv_transaction WHERE client='$client' AND debit='$pago'  AND debitacc='$cuenta1' AND DATE(fecha)='$fecha'";
				
			}			
		
			$result = $mysqli->query($sql);
			$resultCheck = mysqli_num_rows($result);
			if ($resultCheck > 0){
				
							if ($monto < 0){
				
								$pago = abs($monto);
									$sql = "UPDATE rv_transaction SET conciled = 1 WHERE client='$client' AND credit='$pago'  AND creditacc='$cuenta1' AND conciled iS NULL";
								
								
								
							}else if ($monto > 0){
								
								$pago = abs($monto);

							$sql = "UPDATE rv_transaction SET conciled = 1 WHERE client='$client' AND debit='$pago'  AND debitacc='$cuenta1' AND conciled iS NULL";
								
							}
			$result = $mysqli->query($sql);	
			return 1;
			}
}


function createaccounts($mysqli,$client,$number,$alias) {
	
								$coin = 'VEB';
								$balance = '0';
								$user = 1;
								$x=0;
								
									$sql = "SELECT * FROM rv_cuentas WHERE client='$client' AND class1='1' AND class2='1.2'";					
									$result = $mysqli->query($sql);
									$num = mysqli_num_rows($result) + 1;
									$y =  str_replace(".","",1.2);
									
									$code = $client .''. $y .''. $num;
								
								while ($x == 0){
									$sql = "SELECT * FROM rv_cuentas WHERE client='001' AND code='$code'";					
									$result = $mysqli->query($sql);
									$num = mysqli_num_rows($result);

									
									if ($num == 0 ){
										
										$x = 1;
										
									}else {
										$code += 1;										
									}
								}
								
								$code1 = $code;
									
								$sql = "INSERT INTO rv_cuentas (client,class1, class2, numero, alias, balance, code, currency, user) VALUE ('$client', '1', '1.2', '$number', '$alias', '$balance', '$code', '$coin', '$user')";
								$result = $mysqli->query($sql);							



								$coin = 'USD';
								$balance = '0';
								$user = 1;
								$x = 0;
								
									$sql = "SELECT * FROM rv_cuentas WHERE client='$client' AND class1='2' AND class2='2.2'";					
									$result = $mysqli->query($sql);
									$num = mysqli_num_rows($result) + 1;
									$y =  str_replace(".","",2.2);
									
									$code = $client .''. $y .''. $num;
								
								while ($x == 0){
									$sql = "SELECT * FROM rv_cuentas WHERE client='001' AND code='$code'";					
									$result = $mysqli->query($sql);
									$num = mysqli_num_rows($result);

									//echo $code;
									if ($num == 0 ){
										
										$x = 1;
										
									}else {
										$code += 1;										
									}
								}
								
								$code2 = $code;
									
								$sql = "INSERT INTO rv_cuentas (client,class1, class2, numero, alias, balance, code, currency, user) VALUE ('$client', '2', '2.2', '$number', '$alias', '$balance', '$code', '$coin', '$user')";
								$result = $mysqli->query($sql);							



								$sql = "INSERT INTO rv_cliente (client,alias, pc, pp, currency) VALUE ('$client', '$alias', '$code1', '$code2', 'USD')";
								$result = $mysqli->query($sql);							

}






?>