<?php

		include '../../php/conection.php';
		include '../../php/session.php';
			

			$graphs = array();
			
			$u = $_SESSION['id'];
			$result = $mysqli->query("SELECT * FROM login WHERE id='$u'");
			$row = mysqli_fetch_assoc($result);
			$client = $row['client'];	
			$permision = $row['privileges'];
			$agent = $row['Client_id'];
			$where = null;	
			$date = (new DateTime('now', new DateTimezone('America/Caracas')))->format("Y/m/d");	
			
			
			if ($client == '001' && $agent == '159'){
				return;
			}


			$where = null;
			
			
			if ($client == "701" || $permision == "CLIENTE"){
				$where .= " AND Agente='$agent'";
			}

			/*GRAFICO 1*/
			$data = array();
			$data['labels'] = array();
			$data['datasets'] = array();
			$var =  $d = array();
			$var['label'] = "Giros últimos 6 meses";
			$d['label'] = "Pronóstico";
			$var['data'] = $d['data'] = array();
			$var['backgroundColor'] = "rgba(255, 206, 86, 1)";
			$dayNum = strtolower(date("d",strtotime($date)));
			$dayNum = intval($dayNum);
			$sql = "SELECT COUNT(*) as c, Month(Fecha) as m, Year(Fecha) as y FROM giros_sinprocesar WHERE (client_id='$client' OR admin='$client') AND estado != 'ANULADO' AND Fecha > DATE_SUB(now(), INTERVAL 12 MONTH) $where GROUP BY Year(Fecha), Month(Fecha)";
			$result = $mysqli->query($sql);
			$i = 1;
			$n = $result->num_rows;
			if ($result->num_rows > 0){
				$count = $result->num_rows;
				while($row = mysqli_fetch_assoc($result)){
					
					
					array_push($data['labels'],$row['m']."-".$row['y']);
					array_push($var['data'],$row['c']);
					
					
					
					if ($i == $n){
						$days = date("t");
						array_push($d['data'],round($row['c'] / $dayNum * $days,0));
					}else{
						array_push($d['data'],0);
					}
					
					++$i;
				}
			}
			
			array_push($data['datasets'],$var);
			array_push($data['datasets'],$d);
			
			
			
			array_push($graphs,$data);

			
			
			
			
			array_push($data['datasets'],$var);
			
			array_push($graphs,$data);


			
			$json = json_encode($graphs, true);
			echo $json;
			
			
			

?>

